

describe('localStorage.setItem', function() {
    it(function() {
      const cityValue = 'Москва';
      document.getElementById('city_all').value = cityValue;
  
      localStorage.setItem('city', JSON.stringify(document.getElementById('city_all').value));
      const storedCity = JSON.parse(localStorage.getItem('city'));
      const currentCityElement = document.getElementById('current_city');
      const modalAppCityElement = document.getElementById('modalApp_city');
      assert.strictEqual(storedCity, cityValue);
      assert.strictEqual(currentCityElement.textContent, cityValue);
      assert.strictEqual(modalAppCityElement.style.display, 'none');
    });
  });

  describe('addEventListener', function() {
    it(function() {
      addEventListener();
      const event = new dom.window.KeyboardEvent('keydown', { key: 'Escape' });
      dom.window.document.dispatchEvent(event);
      const modals = dom.window.document.getElementsByClassName('modalAppSection');
      for (let i = 0; i < modals.length; i++) {
        assert.strictEqual(modals[i].style.display, 'none');
      }
    });
  });

  describe(function() {
    it(function() {
      const dom = new JSDOM('<!DOCTYPE html><div class="modalAppSection"></div>');
      const { window } = dom;
      const { document } = window;
      const event = new window.KeyboardEvent('keydown', { key: 'Escape' });
      document.dispatchEvent(event);
      const modals = document.getElementsByClassName('modalAppSection');
      for (let i = 0; i < modals.length; i++) {
        assert.strictEqual(modals[i].style.display, 'none');
      }
    });
  });