<?php
    $conn = mysqli_connect('localhost', 'root', '', 'praktica');
    // if(mysqli_error($conn)) {
    //     echo 'Error: '. $conn -> error;
    // }
    
// $login = $_POST['login'];
// $password = $_POST['password'];
// $adres = $_POST['adres'];
// $type = $_POST['type'];


//     $sql = "INSERT INTO Users(Login, Password, Adres, Type) VALUES ('$login', '$password', '$adres', '$type')";
//     $result = $conn -> query($sql);

//     $query = "SELECT * FROM City";
// $res = mysqli_query($conn, $query);
// $data = [];

// while ($row = mysqli_fetch_assoc($res)) {
//     array_push($data, $row['City']);
// }

// $json = json_encode($data);

// print_r ($json);

$query = "SELECT * FROM predpr";
$res = mysqli_query($conn, $query);
$data = [];

while ($row = mysqli_fetch_assoc($res)) {
    array_push($data, [$row['id'],$row['Adres'], $row['Name'], $row['Image'], $row['Menu'], $row['city']]);
}

$json = json_encode($data);

print_r ($json);

?>