<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<section class="modalAppSection" id="modalApp_city">
    <article id="modalApp_cityCon">
        <h1>ВЫБЕРИТЕ ВАШ ГОРОД</h1>
        <select id="city_all">
        
        </select>
        <button id="city_confirm" class="btn_background">ПОДТВЕРДИТЬ</button>
    </article>
 </section>

<body>
<header>
    <article>
        <p id="logo">ALPHA DELIVERY</p>
        <p id="current_city">Ваш город</p>
    </article>

    <article>
        <p>О нас</p>
        <p>Как заказать доставку</p>
        <p class="kurer_button">Стать курьером</p>
        
        <section class="modalAppSection" id="modalApp_kurer">
            <article id="modalAppInfo_text">
                <p>asdasdasdasdads</p>
            </article>
         </section>
        <button id="lk_btn"><img src="assets/lk.png" alt=""></button>

        <section id="accordeonReg">
            <h1>Регистрация</h1>
<form method="GET" id="regForm" name="regForm">
    <input type="text" name="login" placeholder="login" value="login">
    <input type="text" name="password" placeholder="password" value="password">
    <input type="text" name="adres" placeholder="adres" value="adres">
    <select name="type" value="type">
        <option value="Пользователь">Пользователь</option>
        <option value="Курьер">Курьер</option>
    </select>

    <button type="submit" class="btn_background" id="btnReg">Зарегистрироваться</button>
</form>
          </section>


    </article>
</header>

<section id="mainPage">
    <article>
        <p id="mainPrimary">МЫ - МЕЖДУГОРОДНЯЯ <br>СЛУЖБА ДОСТАВКИ <br>ГОРЯЧЕЙ ЕДЫ №1</p>
        <button class="btn_background"><a href="#predprAll">Заказать доставку</a></button>
        <button class="kurer_button btn_noBackground">Стать курьером</button>
    </article>
</section>

<section id="prem">
<h1>НАШИ ПРЕИМУЩЕСТВА</h1>

<p>БЫСТРАЯ ДОСТАВКА</p>
<p>БОЛЬШОЙ ВЫБОР</p>
<p>МНОЖЕСТВО ГОРОДОВ</p>
<p>МНОГО КУРЬЕРОВ</p>

<button class="btn_background">СДЕЛАТЬ ЗАКАЗ</button>
</section>

<section id="predprAll">
    <h1>ПРЕДПРИЯТИЯ В ВАШЕМ ГОРОДЕ</h1>

    <section id="predprAll_cards">
<!-- <article class="card" id="1">
<h2>Папа Джонс</h2>
<img src="assets/card1.png" alt="">
<p>ул.Ломоносова, д.15., корпус 1</p>
<button class="btn_background">Заказать доставку</button>
<button class="btn_noBackground">Меню</button>
</article>

<article class="card" id="2">
    <h2>Папа Джонс</h2>
    <img src="assets/card1.png" alt="">
    <p>ул.Ломоносова, д.15., корпус 1</p>
    <button class="btn_background">Заказать доставку</button>
    <button class="btn_noBackground">Меню</button>
    </article>

    
<article class="card" id="2">
    <h2>Папа Джонс</h2>
    <img src="assets/card1.png" alt="">
    <p>ул.Ломоносова, д.15., корпус 1</p>
    <button class="btn_background">Заказать доставку</button>
    <button class="btn_noBackground">Меню</button>
    </article>

    <article class="card" id="2">
        <h2>Папа Джонс</h2>
        <img src="assets/card1.png" alt="">
        <p>ул.Ломоносова, д.15., корпус 1</p>
        <button class="btn_background">Заказать доставку</button>
        <button class="btn_noBackground">Меню</button>
        </article>

        <article class="card" id="2">
            <h2>Папа Джонс</h2>
            <img src="assets/card1.png" alt="">
            <p>ул.Ломоносова, д.15., корпус 1</p>
            <button class="btn_background">Заказать доставку</button>
            <button class="btn_noBackground">Меню</button>
            </article>

            <article class="card" id="2">
                <h2>Папа Джонс</h2>
                <img src="assets/card1.png" alt="">
                <p>ул.Ломоносова, д.15., корпус 1</p>
                <button class="btn_background">Заказать доставку</button>
                <button class="btn_noBackground">Меню</button>
                </article>

                <article class="card" id="2">
                    <h2>Папа Джонс</h2>
                    <img src="assets/card1.png" alt="">
                    <p>ул.Ломоносова, д.15., корпус 1</p>
                    <button class="btn_background">Заказать доставку</button>
                    <button class="btn_noBackground">Меню</button>
                    </article> -->
                </section>

</section>

<section id="delivery">
<h1>ПРЕИМУЩЕСТВА НАШЕЙ КУРЬЕРСКОЙ ПРОГРАММЫ</h1>
<p>БЫСТРЫЕ ВЫПЛАТЫ</p>
<p>ЕЖЕДНЕВНЫЕ ЗАКАЗЫ</p>
<p>ИНДИВИДУАЛЬНЫЙ ПОДХОД</p>
<p>ПОСТОЯННАЯ ПОДДЕРЖКА</p>
<button class="kurer_button btn_background">СТАТЬ КУРЬЕРОМ</button>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="script.js"></script>
</body>
</html>

